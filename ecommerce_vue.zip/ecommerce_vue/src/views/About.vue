<template>
  <div class="about">
    <strong>Welcome to Hamro Garden, your number one source for all things ie: plants, gardening tools and seeds.<br><br>
     We're dedicated to giving you the very best of our product, with a focus on three characteristics, ie: dependability, customer service and uniqueness.<br><br>
       Founded in 2021 by Aarogya Thapaliya, Rahul Kumar Mainali, Rastra Dhoj Karki and Surya Kumar Mahato, Hamro Garden has come a long way from its beginnings in a Kathmandu, Nepal.<br><br> When Aarogya first started out, his passion for making the availability of plants and gardening tools easier to Biophilia people.<br><br>
</strong>
<p>------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------</p><br>
<strong>
We hope you enjoy our products as much as we enjoy offering them to you. If you have any questions or comments, please don't hesitate to contact us.

Sincerely,
Hamro Garden Team
</strong>
  </div>
</template>
